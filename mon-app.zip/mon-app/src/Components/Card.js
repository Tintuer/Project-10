import React from "react"
import { Card, Button } from 'react-bootstrap';
import "./Card.css"


function MyCard(props) {
    console.log(props.article.data);
    return (
        <>
            <br />
            <Card bg="dark" text="white" key={props.key} style={{ maxWidth: '18rem' }}>
                <Card.Img height="250px" variant="top" src={props.article.attributes.image.data ? "http://localhost:1337" + props.article.attributes.image.data.attributes.url : null} />
                <Card.Body >
                    <Card.Title >{props.article.attributes.name}</Card.Title>
                    <Card.Subtitle className="mb-2 text-muted">{props.article.attributes.categories}</Card.Subtitle>
                    <Card.Text>
                        {props.article.attributes.Price} €
                    </Card.Text>
                    <Button onClick={() => props.addItem(props.article)} >Add to cart</Button>
                    {/* <Button onClick={() => { props.addFilter("fastfood") }}>filter</Button> */}
                </Card.Body>

            </Card>
            <br />

        </>
    );
}

export default MyCard;