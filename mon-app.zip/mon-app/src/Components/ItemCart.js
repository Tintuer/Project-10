import React from "react"
import { Card, Button } from 'react-bootstrap';
import "./Card.css"


function ItemCart(props) {
    console.log(props.element.data);
    return (
        <>
            <br />
            <Card bg="dark" text="white" key={props.key} style={{ maxWidth: '18rem' }}>
                <Card.Img height="250px" variant="top" src={props.element.attributes.image.data ? "http://localhost:1337" + props.element.attributes.image.data.attributes.url : null} />
                <Card.Body >
                    <Card.Title >{props.element.attributes.name}</Card.Title>
                    <Card.Subtitle className="mb-2 text-muted">{props.element.attributes.categories}</Card.Subtitle>
                    <Card.Text>
                        {props.element.attributes.Price} €
                    </Card.Text>
                    <Button onClick={() => { props.removeArticle(props.element) }}>Remove</Button>
                </Card.Body>

            </Card>
            <br />

        </>
    );
}

export default ItemCart;