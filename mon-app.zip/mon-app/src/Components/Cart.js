import { useState } from "react";
import { Button, Modal } from "react-bootstrap";
import ItemCart from "./ItemCart";





function MyCart(props) {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
  <>
    <Button variant="primary" onClick={handleShow}>
      Cart
    </Button>

    <Modal
      show={show}
      onHide={handleClose}
      backdrop="static"
      keyboard={false}
      size="lg"
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          Cart
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {props.cart.map((element) => <ItemCart cart={props.cart} element = {element} removeArticle={props.removeArticle}/>)}
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Close
        </Button>
        <Button variant="primary">Pay</Button>
      </Modal.Footer>
    </Modal>
  </>
  );
}

export default MyCart;