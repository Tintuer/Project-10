import '../App.css';
import { Container, Navbar, Form, FormControl } from 'react-bootstrap';
import './MyNavbar.css';
import MyCart from './Cart';


function MyNavbar(props) {
    return (
        <div className="App">
            <header className="App-header">
                <Navbar className ="color-nav" bg="purple" variant ="black">
                    <Container>
                        <Navbar.Brand href="#home">
                            <img
                            alt=""
                            src="../favicon.ico"
                            width="60"
                            height="60"
                            className="text-center"
                            />{' '}
                            Cell Society
                        </Navbar.Brand>
                        <Navbar.Collapse className="justify-content-end">
                            <Form className="d-flex">
                                <FormControl
                                    type="search"
                                    placeholder="Search"
                                    className="me-2"
                                    aria-label="Search"
                                    name = "search"
                                    onChange = {(e) => props.handleChange(e)}
                                />
                                <MyCart cart={props.cart} removeArticle={props.removeArticle}/>
                                </Form>
                        </Navbar.Collapse>
                        <Navbar.Toggle aria-controls="basic-navbar-nav" />
                        <Navbar.Collapse id="basic-navbar-nav"></Navbar.Collapse>
                    </Container>
                </Navbar>
            </header>
        </div>
    );
}

export default MyNavbar;
